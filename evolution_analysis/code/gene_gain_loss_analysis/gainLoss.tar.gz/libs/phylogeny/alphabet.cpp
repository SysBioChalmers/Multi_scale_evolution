// $Id: alphabet.cpp 962 2006-11-07 15:13:34Z privmane $

#include "alphabet.h"

alphabet::~alphabet(){}
// this must be here. see Effective c++ page 63 (item 14, constructors, destructors, 
// assignment
